use hms;
create table customer_details(id int primary key auto_increment,
name varchar(20) not null,
 gender varchar(6) not null,
 email varchar(30) not null,
 mobile varchar(13) not null, 
 address varchar(50) not null,
 country varchar(15) not null,
 typeOfId varchar(10) not null ,
 idNo varchar(20) not null , 
 pasword varchar(16) not null);
 insert into customer_details values(1,'Admin','male','admin@gmail.com',
'8860452595','RDEC Ghaizbad','India','Aadhar','158915891589','admin');
select * from customer_details;
alter table customer_details modify email varchar(30) unique key not null;
select * from customer_details where email='byhh@gmail.com' and pasword='byhh1589';
create table admin_details(email varchar(30) primary key , pasword varchar(16) not null);
insert into admin_details values('Admin','Admin');
select * from admin_details;
create table hotel_list(hotel_name varchar(30) not null ,
hotel_city varchar(20) not null,
hotel_address varchar(20) not null,
total_room int not null,
contact_number int not null,
rating int(1) not null);
commit;
select * from hotel_list;
update customer_details set pasword=12345 where email='adnan@gmail.com';
create table booked_hotel_customer(customer_name varchar(20) not null,
hotel_name varchar(30) not null,
from_date varchar(12) not null,
to_date varchar(12) not null,
rooms_booked int not null, primary key(hotel_name , customer_name));
drop table booked_hotel_customer;
insert into booked_hotel_customer values('adnan','The Taj','2008-4-07','2008-4-12',2);
select * from booked_hotel_customer;
rollback;
commit;
