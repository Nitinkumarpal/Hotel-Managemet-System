package hms.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class HmsDbUtil {
	
	public static Connection getConnection() {
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hms","root","8860452595");
			return con;
		}catch(Exception e) {
			return con;
		}
		
	}

}
